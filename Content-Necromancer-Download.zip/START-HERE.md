# Content Necromancer — by Nina of She Knows SEO

https://sheknowsseo.co

Content Necromancer is a paid historical-recovery upgrade for an existing Hidden Gem Vault. It searches only the older archives, accounts or folders you approve, avoids routine Collector coverage, protects duplicates and permissions, saves approved discoveries into your current Vault, then mines source-linked Gems. It does not write or publish finished content.

## Start with the skill file

1. Keep `Content-Necromancer.skill` as downloaded; it is already a ZIP archive in the skill format.
2. If your ChatGPT Work account offers skill upload, choose this file in that upload control.
3. Start a Work task with Airtable connected, select Content Necromancer and answer its first question about your Vault.

Skill upload controls and labels vary and have not been verified on every account. If you cannot find a skill upload option, attach `Content-Necromancer.md` to a new Work task instead and ask Work to follow it. The Markdown gives that task the instructions; it does not install an account-wide skill.

## What happens next

Work checks your existing Vault, then asks one question at a time about the exact archive, date range, item cap, goal and permissions. It tests a tiny sample before asking whether to expand. You handle sign-ins and any manual export or upload it identifies.

Choose one small, clearly named source first. A cloud Work task cannot read a folder on your desktop unless you upload it or use a local-capable task. No schedule is created automatically; most historical recoveries should be finite.

No Airtable records, source accounts or schedules are included in this download. You need the free Hidden Gem Vault already set up, your own source access and an Airtable connection for live imports.
