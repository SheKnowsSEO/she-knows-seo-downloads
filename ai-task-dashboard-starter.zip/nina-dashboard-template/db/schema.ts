import { integer, sqliteTable, text } from "drizzle-orm/sqlite-core";

export const tasks = sqliteTable("tasks", {
  id: text("id").primaryKey(),
  title: text("title").notNull(),
  project: text("project").notNull().default("Operations"),
  status: text("status").notNull().default("open"),
  priority: text("priority").notNull().default("medium"),
  timeframe: text("timeframe").notNull().default("week"),
  dueDate: text("due_date").notNull().default(""),
  notes: text("notes").notNull().default(""),
  url: text("url").notNull().default(""),
  source: text("source").notNull().default("manual"),
  owner: text("owner").notNull().default("Me"),
  needsConfirmation: integer("needs_confirmation").notNull().default(0),
  createdAt: text("created_at").notNull(),
  updatedAt: text("updated_at").notNull(),
  completedAt: text("completed_at").notNull().default(""),
});
