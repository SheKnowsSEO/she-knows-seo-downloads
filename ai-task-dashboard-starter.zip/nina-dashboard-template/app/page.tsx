import type { Metadata } from "next";
import { Dashboard } from "./dashboard";

export const metadata: Metadata = {
  title: "Actually Useful To-Do List",
  description: "A focused weekly dashboard that keeps future work out of sight until it matters.",
};

export default function Home() {
  return <Dashboard />;
}
