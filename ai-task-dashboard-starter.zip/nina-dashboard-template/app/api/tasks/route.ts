import { env } from "cloudflare:workers";

type TaskPayload = Record<string, unknown>;

function getD1() {
  if (!env.DB) throw new Error("The task database is not connected yet. Set up the DB binding before using the dashboard.");
  return env.DB;
}

async function ensureDatabase() {
  const db = getD1();
  await db.batch([
    db.prepare(`CREATE TABLE IF NOT EXISTS tasks (id TEXT PRIMARY KEY,title TEXT NOT NULL,project TEXT NOT NULL DEFAULT 'Operations',status TEXT NOT NULL DEFAULT 'open',priority TEXT NOT NULL DEFAULT 'medium',timeframe TEXT NOT NULL DEFAULT 'week',due_date TEXT NOT NULL DEFAULT '',notes TEXT NOT NULL DEFAULT '',url TEXT NOT NULL DEFAULT '',source TEXT NOT NULL DEFAULT 'manual',owner TEXT NOT NULL DEFAULT 'Me',needs_confirmation INTEGER NOT NULL DEFAULT 0,created_at TEXT NOT NULL,updated_at TEXT NOT NULL,completed_at TEXT NOT NULL DEFAULT '')`),
    db.prepare("CREATE INDEX IF NOT EXISTS idx_tasks_status_due ON tasks(status, due_date)"),
    db.prepare("CREATE INDEX IF NOT EXISTS idx_tasks_timeframe_status ON tasks(timeframe, status)"),
  ]);
  return db;
}

function normalise(payload: TaskPayload) {
  const status = ["open", "waiting", "done"].includes(String(payload.status)) ? String(payload.status) : "open";
  const priority = ["high", "medium", "low"].includes(String(payload.priority)) ? String(payload.priority) : "medium";
  const timeframe = ["week", "future"].includes(String(payload.timeframe)) ? String(payload.timeframe) : "week";
  return { id: String(payload.id || crypto.randomUUID()), title: String(payload.title || "").trim(), project: String(payload.project || "Operations").trim(), status, priority, timeframe, dueDate: String(payload.dueDate || ""), notes: String(payload.notes || ""), url: String(payload.url || ""), source: String(payload.source || "manual"), owner: String(payload.owner || "Me"), needsConfirmation: Number(payload.needsConfirmation || 0) ? 1 : 0 };
}

export async function GET() {
  try {
    const db = await ensureDatabase();
    const result = await db.prepare(`SELECT id,title,project,status,priority,timeframe,due_date AS dueDate,notes,url,source,owner,needs_confirmation AS needsConfirmation,created_at AS createdAt,updated_at AS updatedAt,completed_at AS completedAt FROM tasks ORDER BY CASE status WHEN 'open' THEN 0 WHEN 'waiting' THEN 1 ELSE 2 END, CASE priority WHEN 'high' THEN 0 WHEN 'medium' THEN 1 ELSE 2 END, CASE WHEN due_date = '' THEN 1 ELSE 0 END, due_date, updated_at DESC`).all();
    return Response.json({ tasks: result.results });
  } catch (error) { return Response.json({ error: error instanceof Error ? error.message : "Could not load tasks" }, { status: 500 }); }
}

export async function POST(request: Request) {
  try {
    const task = normalise(await request.json() as TaskPayload);
    if (!task.title) return Response.json({ error: "A task needs a title." }, { status: 400 });
    const db = await ensureDatabase(); const now = new Date().toISOString();
    await db.prepare(`INSERT INTO tasks (id,title,project,status,priority,timeframe,due_date,notes,url,source,owner,needs_confirmation,created_at,updated_at,completed_at) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)`).bind(task.id, task.title, task.project, task.status, task.priority, task.timeframe, task.dueDate, task.notes, task.url, task.source, task.owner, task.needsConfirmation, now, now, task.status === "done" ? now : "").run();
    return Response.json({ ok: true, id: task.id }, { status: 201 });
  } catch (error) { return Response.json({ error: error instanceof Error ? error.message : "Could not add task" }, { status: 500 }); }
}

export async function PUT(request: Request) {
  try {
    const task = normalise(await request.json() as TaskPayload);
    if (!task.id || !task.title) return Response.json({ error: "A valid task is required." }, { status: 400 });
    const db = await ensureDatabase(); const now = new Date().toISOString();
    await db.prepare(`UPDATE tasks SET title=?,project=?,status=?,priority=?,timeframe=?,due_date=?,notes=?,url=?,source=?,owner=?,needs_confirmation=?,updated_at=?,completed_at=? WHERE id=?`).bind(task.title, task.project, task.status, task.priority, task.timeframe, task.dueDate, task.notes, task.url, task.source, task.owner, task.needsConfirmation, now, task.status === "done" ? now : "", task.id).run();
    return Response.json({ ok: true });
  } catch (error) { return Response.json({ error: error instanceof Error ? error.message : "Could not update task" }, { status: 500 }); }
}
