"use client";

import { FormEvent, useEffect, useMemo, useState } from "react";

type Status = "open" | "waiting" | "done";
type Priority = "high" | "medium" | "low";
type Timeframe = "week" | "future";
type Filter = "week" | "future" | "waiting" | "done";

type Task = {
  id: string;
  title: string;
  project: string;
  status: Status;
  priority: Priority;
  timeframe: Timeframe;
  dueDate: string;
  notes: string;
  url: string;
  source: string;
  owner: string;
  needsConfirmation: number;
  createdAt: string;
  updatedAt: string;
  completedAt: string;
};

const blankTask: Partial<Task> = {
  title: "",
  project: "Operations",
  status: "open",
  priority: "medium",
  timeframe: "week",
  dueDate: "",
  notes: "",
  url: "",
  source: "manual",
  owner: "Me",
  needsConfirmation: 0,
};

const studentWords = [
  "student", "module", "workbook", "lesson", "pickaxe",
  "knowledgebase", "course", "digital-product review", "gss research app",
];

function torontoDate() {
  const parts = new Intl.DateTimeFormat("en-CA", {
    year: "numeric",
    month: "2-digit",
    day: "2-digit",
    timeZone: "America/Toronto",
  }).formatToParts(new Date());
  const value = Object.fromEntries(parts.map(part => [part.type, part.value]));
  return `${value.year}-${value.month}-${value.day}`;
}

function sundayFor(date: string) {
  const point = new Date(`${date}T12:00:00Z`);
  point.setUTCDate(point.getUTCDate() + (7 - point.getUTCDay()) % 7);
  return point.toISOString().slice(0, 10);
}

function friendlyDate(value: string) {
  if (!value) return "No deadline";
  const parsed = new Date(`${value}T12:00:00-04:00`);
  if (Number.isNaN(parsed.getTime())) return "No deadline";
  return new Intl.DateTimeFormat("en-CA", {
    month: "short",
    day: "numeric",
    timeZone: "America/Toronto",
  }).format(parsed);
}

function studentFacing(task: Task) {
  const text = `${task.title} ${task.project} ${task.notes}`.toLowerCase();
  return studentWords.some(word => text.includes(word));
}

function priorityIndex(priority: Priority) {
  return ["high", "medium", "low"].indexOf(priority);
}

function TaskNotes({ text }: { text: string }) {
  const lines = text.split(/\r?\n/).map(line => line.trim()).filter(Boolean);
  if (!lines.length) return null;

  const isChecklist = (line: string) => /^(?:[-*]\s*)?(?:\[ ?\]|☐|□)\s*/.test(line);
  const isBullet = (line: string) => /^[-*•]\s+/.test(line) && !isChecklist(line);
  const clean = (line: string) => line
    .replace(/^(?:[-*]\s*)?(?:\[ ?\]|☐|□)\s*/, "")
    .replace(/^[-*•]\s+/, "")
    .replace(/\s{2,}/g, " ")
    .trim();

  const hasList = lines.some(line => isChecklist(line) || isBullet(line));
  if (!hasList) return <p className="task-notes">{text.replace(/\s{2,}/g, " ").trim()}</p>;

  return (
    <div className="task-notes task-notes-list">
      <ul>
        {lines.map((line, index) => (
          <li key={`${line}-${index}`}>
            {isChecklist(line) && <input type="checkbox" aria-label={clean(line)} disabled />}
            <span>{clean(line)}</span>
          </li>
        ))}
      </ul>
    </div>
  );
}

export function Dashboard() {
  const [tasks, setTasks] = useState<Task[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");
  const [filter, setFilter] = useState<Filter>("week");
  const [query, setQuery] = useState("");
  const [editing, setEditing] = useState<Partial<Task> | null>(null);
  const today = torontoDate();
  const weekEnd = sundayFor(today);

  async function loadTasks() {
    try {
      const response = await fetch("/api/tasks", { cache: "no-store" });
      const data = await response.json();
      if (!response.ok) throw new Error(data.error || "Could not load tasks");
      setTasks(data.tasks);
      setError("");
    } catch (err) {
      setError(err instanceof Error ? err.message : "Could not load tasks");
    } finally {
      setLoading(false);
    }
  }

  useEffect(() => { void loadTasks(); }, []);

  function isFuture(task: Task) {
    return task.timeframe === "future" || Boolean(task.dueDate && task.dueDate > weekEnd);
  }

  function isOverdue(task: Task) {
    return Boolean(task.dueDate && task.status !== "done" && task.dueDate < today);
  }

  function attentionRank(task: Task) {
    if (isOverdue(task)) return 0;
    if (task.dueDate && task.dueDate <= weekEnd) return 1;
    if (studentFacing(task)) return 2;
    return 3;
  }

  function sortFocused(a: Task, b: Task) {
    const rank = attentionRank(a) - attentionRank(b);
    if (rank !== 0) return rank;
    const due = (a.dueDate || "9999").localeCompare(b.dueDate || "9999");
    if (due !== 0) return due;
    return priorityIndex(a.priority) - priorityIndex(b.priority);
  }

  const openTasks = tasks.filter(task => task.status !== "done");
  const confirms = openTasks.filter(task => task.needsConfirmation);
  const weekTasks = openTasks.filter(task => task.status === "open" && !isFuture(task)).sort(sortFocused);
  const futureTasks = openTasks.filter(task => task.status === "open" && isFuture(task));
  const focus = weekTasks.slice(0, 3);

  const visible = useMemo(() => {
    const filtered = tasks.filter(task => {
      if (filter === "week") return task.status === "open" && !isFuture(task);
      if (filter === "future") return task.status === "open" && isFuture(task);
      return task.status === filter;
    });
    const searched = filtered.filter(task => {
      const haystack = `${task.title} ${task.project} ${task.notes}`.toLowerCase();
      return haystack.includes(query.toLowerCase());
    });
    return filter === "week" ? searched.sort(sortFocused) : searched;
  }, [tasks, filter, query, today, weekEnd]);

  async function saveTask(event: FormEvent) {
    event.preventDefault();
    if (!editing?.title?.trim()) return;
    const response = await fetch("/api/tasks", {
      method: editing.id ? "PUT" : "POST",
      headers: { "content-type": "application/json" },
      body: JSON.stringify({ ...editing, owner: "Me" }),
    });
    const data = await response.json();
    if (!response.ok) { setError(data.error || "Could not save task"); return; }
    setEditing(null);
    await loadTasks();
  }

  async function updateTask(task: Task, changes: Partial<Task>) {
    const response = await fetch("/api/tasks", {
      method: "PUT",
      headers: { "content-type": "application/json" },
      body: JSON.stringify({ ...task, ...changes }),
    });
    if (!response.ok) { setError("That update did not stick. Please try again."); return; }
    await loadTasks();
  }

  if (loading) return <main className="loading">Loading this week…</main>;

  const labels: Array<[Filter, string]> = [
    ["week", "This week"],
    ["future", "Future"],
    ["waiting", "Waiting"],
    ["done", "Done"],
  ];

  const sectionLabels: Record<Filter, string> = {
    week: "This week",
    future: "Parked for later",
    waiting: "Waiting on something",
    done: "Finished",
  };

  return (
    <main className="shell">
      <header className="topbar">
        <div className="brand"><span className="brand-mark">+</span><span>My HQ</span></div>
        <div className="scan-status"><span className="pulse" />Weekly planning brief</div>
      </header>

      {error && <div className="error-banner" role="alert">{error}</div>}

      <section className="hero">
        <div className="hero-copy">
          <div className="kicker">This week</div>
          <h1>What needs doing now.</h1>
          <p>Deadlines first. Student-facing work next. Everything else can wait somewhere you do not have to stare at it.</p>
        </div>
        <aside className="focus-card">
          <p className="eyebrow">Start here</p>
          <h2>Top three</h2>
          <div className="focus-list">
            {focus.map((task, index) => (
              <div className="focus-item" key={task.id}>
                <span className="focus-number">{index + 1}</span>
                <div>
                  <div className="focus-title">{task.title}</div>
                  <div className="focus-meta">{friendlyDate(task.dueDate)} · {task.project}</div>
                </div>
              </div>
            ))}
          </div>
        </aside>
      </section>

      <section className="stats" aria-label="Task summary">
        <div className="stat"><div className="stat-value">{weekTasks.length}</div><div className="stat-label">This week</div></div>
        <div className="stat"><div className="stat-value">{weekTasks.filter(task => task.dueDate).length}</div><div className="stat-label">Have deadlines</div></div>
        <div className="stat"><div className="stat-value">{weekTasks.filter(studentFacing).length}</div><div className="stat-label">Student-facing</div></div>
        <div className="stat"><div className="stat-value">{futureTasks.length}</div><div className="stat-label">Parked for later</div></div>
      </section>

      {confirms.length > 0 && (
        <section className="confirm-panel">
          <div className="confirm-head"><div><h2>Did this happen?</h2><p>The agent checked first. These are the only bits it still cannot verify.</p></div></div>
          <div className="confirm-row">
            {confirms.map(task => (
              <div className="confirm-pill" key={task.id}>
                <strong>{task.title}</strong>
                <div className="confirm-actions">
                  <button className="tiny-button yes" onClick={() => updateTask(task, { status: "done", needsConfirmation: 0 })}>Yep ✓</button>
                  <button className="tiny-button no" onClick={() => updateTask(task, { needsConfirmation: 0 })}>Nope</button>
                </div>
              </div>
            ))}
          </div>
        </section>
      )}

      <div className="toolbar">
        <div className="toolbar-left" role="group" aria-label="Filter tasks">
          {labels.map(([value, label]) => (
            <button key={value} className={`filter ${filter === value ? "active" : ""}`} onClick={() => setFilter(value)}>{label}</button>
          ))}
        </div>
        <div className="toolbar-right">
          <input className="search" value={query} onChange={event => setQuery(event.target.value)} placeholder="Find a task…" aria-label="Search tasks" />
          <button className="add-button" onClick={() => setEditing({ ...blankTask })}>+ Add task</button>
        </div>
      </div>

      <div className="section-title"><h2>{sectionLabels[filter]}</h2><span>{visible.length} showing</span></div>
      <section className="task-grid">
        {visible.length === 0 && <div className="empty">Nothing here. Exactly as intended.</div>}
        {visible.map(task => (
          <article className={`task priority-${task.priority} ${task.status === "done" ? "done" : ""}`} key={task.id}>
            <div className="task-top">
              <div className="chips">
                <span className="chip project-chip">{task.project}</span>
                {task.dueDate && <span className="chip deadline-chip">Deadline</span>}
                {studentFacing(task) && <span className="chip student-chip">Student-facing</span>}
              </div>
              <button className="icon-button" aria-label={task.status === "done" ? "Reopen task" : "Mark task done"} onClick={() => updateTask(task, { status: task.status === "done" ? "open" : "done" })}>{task.status === "done" ? "↺" : "✓"}</button>
            </div>
            <h3>{task.title}</h3>
            <TaskNotes text={task.notes || task.project} />
            <div className="task-bottom">
              <span className={`due ${isOverdue(task) ? "overdue" : ""}`}>{isOverdue(task) ? "Overdue · " : ""}{friendlyDate(task.dueDate)}</span>
              <div>{task.url && <a className="task-link" href={task.url} target="_blank" rel="noreferrer">Open source ↗</a>} <button className="tiny-button" onClick={() => setEditing(task)}>Edit</button></div>
            </div>
          </article>
        ))}
      </section>

      <p className="footer-note">Future work stays parked until it is genuinely time to care about it.</p>

      {editing && (
        <div className="modal-backdrop" role="presentation" onClick={event => { if (event.target === event.currentTarget) setEditing(null); }}>
          <form className="modal" onSubmit={saveTask}>
            <h2>{editing.id ? "Edit task" : "Add a task"}</h2>
            <div className="form-grid">
              <div className="field wide"><label htmlFor="title">Task</label><input id="title" autoFocus required value={editing.title || ""} onChange={event => setEditing({ ...editing, title: event.target.value })} /></div>
              <div className="field"><label htmlFor="project">Project</label><input id="project" value={editing.project || ""} onChange={event => setEditing({ ...editing, project: event.target.value })} /></div>
              <div className="field"><label htmlFor="timeframe">When</label><select id="timeframe" value={editing.timeframe || "week"} onChange={event => setEditing({ ...editing, timeframe: event.target.value as Timeframe })}><option value="week">This week</option><option value="future">Future</option></select></div>
              <div className="field"><label htmlFor="priority">Priority</label><select id="priority" value={editing.priority || "medium"} onChange={event => setEditing({ ...editing, priority: event.target.value as Priority })}>{["high", "medium", "low"].map(value => <option key={value}>{value}</option>)}</select></div>
              <div className="field"><label htmlFor="status">Status</label><select id="status" value={editing.status || "open"} onChange={event => setEditing({ ...editing, status: event.target.value as Status })}><option value="open">Open</option><option value="waiting">Waiting</option><option value="done">Done</option></select></div>
              <div className="field"><label htmlFor="due">Due date</label><input id="due" type="date" value={editing.dueDate || ""} onChange={event => setEditing({ ...editing, dueDate: event.target.value })} /></div>
              <div className="field"><label htmlFor="source">Source</label><input id="source" value={editing.source || "manual"} onChange={event => setEditing({ ...editing, source: event.target.value })} /></div>
              <div className="field wide"><label htmlFor="url">Source link</label><input id="url" type="url" value={editing.url || ""} onChange={event => setEditing({ ...editing, url: event.target.value })} /></div>
              <div className="field wide"><label htmlFor="notes">Useful context</label><textarea id="notes" value={editing.notes || ""} onChange={event => setEditing({ ...editing, notes: event.target.value })} /></div>
            </div>
            <div className="modal-actions"><button type="button" className="secondary-button" onClick={() => setEditing(null)}>Cancel</button><button className="add-button" type="submit">Save task</button></div>
          </form>
        </div>
      )}
    </main>
  );
}
