# Nina Dashboard Starter Template

This is the reusable starter for the masterclass bonus route.

It contains the dashboard interface, styling, persistent task API shape and database schema. It does not contain Nina’s personal tasks, connector credentials or private data.

## How students use it

1. Copy or attach this folder to a compatible coding/site-building AI tool.
2. Paste the prompt from `SETUP-PROMPT.md`.
3. Answer the setup questions.
4. Complete any required sign-in or connector authorisation.
5. Verify the test task persists after reopening the dashboard.

## Important limitation

This template expects a platform that can run a React/Next-style app with a persistent database binding. A prompt alone cannot create a persistent backend in an environment that only supports temporary browser code.

The setup prompt requires the AI to stop and explain that limitation rather than pretending the dashboard is persistent.
