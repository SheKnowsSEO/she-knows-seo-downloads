# Nina Dashboard Starter — setup prompt

Copy this prompt into the AI tool you are using **after attaching or opening the template folder**.

```text
Set up this starter project as my own private AI task dashboard.

First, inspect every file in the starter project. Treat the existing dashboard components and styles as the visual and interaction template. Do not replace the interface with a generic to-do list.

Before making changes, ask me only for the information you need from this list:

1. What name should appear in the dashboard?
2. What single-letter or short brand mark should appear in the top-left?
3. Which sources should the task-gatherer check? (For example: Google Calendar, Gmail, ClickUp, Slack or another task app.)
4. How often should the task-gatherer run?
5. What day and time should the weekly planning report run?
6. Should the Site be private or public? Default to private.
7. Do I want to keep the template’s visual style, or should I provide a brand guide, website URL, colour palette or screenshots for a custom version?

Do not ask me for tasks yet. Set up the working dashboard first.

## Dashboard requirements

Keep the template’s existing layout and behaviour, including:

- A focused “This week” view
- A future or parked-for-later view
- Waiting and completed states
- Search and filters
- A top-three focus area
- Summary counts
- A confirmation area for uncertain tasks
- Manual add, edit, complete and delete actions
- Responsive desktop and mobile layouts
- Readable normal-weight typography
- Clear empty, loading and error states

Replace all personal example content with neutral empty-state content. Do not copy Nina’s tasks, names, emails, calendar events, connectors, URLs or private information.

## Backend requirements

Set up persistent storage for this user’s tasks. Use the platform’s supported persistent database, such as Sites D1, rather than browser-only localStorage.

Create or verify a `tasks` table with these fields:

- id
- title
- project
- status
- priority
- timeframe
- due date
- notes
- source
- source link
- owner
- needs confirmation
- created date
- updated date
- completed date

Create or verify the database binding, schema, migrations and API routes needed for reading, adding and updating tasks.

Do not claim the database works until you have:

1. Created or verified the table.
2. Loaded the empty dashboard successfully.
3. Added a test task.
4. Reopened or refreshed the dashboard.
5. Confirmed the test task is still present.
6. Deleted the test task.

If the platform cannot provide persistent storage, stop and explain the limitation instead of silently using temporary browser storage.

## Privacy and ownership

- Make the dashboard private by default.
- Do not include a public demo account.
- Default every task owner to me.
- Do not add a “Mine” view because the dashboard is already for me.
- Do not expose task data in page source, example seed data or public metadata.

## Connector setup

After the dashboard and database work, help me connect the sources I named.

For each connector:

- Tell me exactly what permission it needs.
- Explain what information will be read.
- Explain whether the connection is read-only or can make changes.
- Do not send messages, edit external systems or mark tasks complete automatically.
- If a connector is unavailable, say so clearly and continue with the others.

## Task-gatherer agent

Create a read-only task-gatherer agent that checks my selected sources on my chosen schedule.

It should identify:

- Direct requests
- Commitments I made
- Real deadlines
- Upcoming meetings needing preparation
- Follow-ups
- Blocked or waiting-on work
- Unresolved questions

Before suggesting a task, it must check for duplicates, preserve the original source link, use only real dates, default ownership to me and mark uncertainty as “needs confirmation”.

It must never invent a deadline or silently mark something complete.

## Weekly planner agent

Create a weekly planning agent that reviews the dashboard, task-gatherer findings and dated commitments.

Its report must include:

- Executive read
- Needs attention now
- Upcoming meetings and preparation
- Worth watching
- Likely dashboard additions
- Did this happen?
- Decisions needed from me
- Cross-system contradictions
- Recommended next actions
- Can ignore for now
- Coverage notes

For each item, include the owner, real deadline or timing, evidence source and smallest useful next action.

The planner must check the connected sources before asking me questions. It must ask only questions that could materially change the plan.

## Final verification

Once I have answered the setup questions and authorised the connectors, complete the setup as one guided flow:

1. Build or configure the dashboard.
2. Set up persistent task storage.
3. Create the task-gatherer agent.
4. Create the weekly-planner agent.
5. Schedule both agents using the schedule I gave you.
6. Run one task-gathering scan immediately.
7. Run one weekly-planning report immediately.
8. Show me the results.
9. Ask me to confirm whether the results look right.
10. Only then say setup is complete.

If the platform requires me to click a button or approve a schedule, pause and tell me exactly what to click. If the platform cannot create recurring schedules, explain that clearly and give me the closest supported alternative.

Before you say setup is complete, also test:

- The Site is private.
- The dashboard loads.
- The database persists tasks.
- A task can be added, edited, completed and deleted.
- Views and filters work.
- The selected connectors are available.
- The task-gatherer handles duplicates and missing sources correctly.
- The weekly planner produces the required report.

Tell me exactly what worked, what still needs my login or approval, and what I need to do manually next.
```

The prompt is designed to be used with this template’s files. It does not contain Nina’s task data or connector credentials.
