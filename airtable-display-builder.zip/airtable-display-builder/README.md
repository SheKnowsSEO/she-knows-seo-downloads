# Airtable Display Builder 0.3.0

By She Knows SEO. Display your own Airtable records as WordPress feature cards, directory rows or linked bullet lists. Save named displays with independent sources, field mappings, colours and date rules.

## Student installation

1. Download `airtable-display-builder.zip` and keep it zipped.
2. In WordPress, open Plugins → Add Plugin → Upload Plugin.
3. Select the ZIP, install it and activate Airtable Display Builder.
4. Open Airtable Displays in the WordPress menu.
5. Create your own Airtable personal access token with `data.records:read` and `schema.bases:read`, restricted to the bases you want to display. Save it in the plugin's token field. Never put it in a post or shortcode.
6. Create or edit a display. Enter your base ID and select the table and optional view. Map the title, URL and other fields you want shown. Leave unwanted mappings blank.
7. Choose your layout and preview it. Check that all mapped fields are suitable for public display, especially descriptions.
8. Save, then copy the generated shortcode into a WordPress Shortcode block. Preview the page on desktop and mobile before publishing.

You need a WordPress site that permits plugin uploads, administrator access and your own Airtable account. PHP's OpenSSL extension is required. No credentials, saved display settings or She Knows SEO records are included. The plugin reads Airtable; it does not write back to your base. One saved token serves all displays on your site.

## Using displays

Saving a display changes every use of its shortcode. Duplicate it to make an independent copy. Date filtering is optional; configure per-record date mappings or display-wide start and expiry dates as appropriate.

Records are cached for five minutes. Sources/views are limited to 5,000 records. Use a smaller view for larger tables. Page caches and CDNs can delay changes and expiry: configure cache expiry/purging to suit your schedule. Saving a display calls WP Rocket's purge function when available; other layers may need separate purging. Airtable attachment URLs can expire, so check images with your page cache.

Plugin updates require uploading a newer ZIP. This package does not add automatic WordPress updates. Back up and test on staging before replacing an existing installation; do not delete the plugin as an update step.

## Troubleshooting

- No records: check token permissions, base/table/view, mappings, date rules and the connection check. Records without a mapped title are omitted.
- Schema dropdowns fail: check `schema.bases:read` and access to the chosen base.
- Changes do not appear: allow for the record cache and clear relevant page/CDN caches.

## Verification status

Version 0.3.0 was observed active on She Knows SEO on 23 October 2026. This distribution preserves the locally saved 0.3.0 PHP, JavaScript and CSS without changes. ZIP integrity and equality with those saved code files were checked. A fresh student-site installation and compatibility across themes, hosts and caching services were not verified in this packaging session.
