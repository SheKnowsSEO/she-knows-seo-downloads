(() => {
  'use strict';
  const search = document.getElementById('adb-search');
  if (search) search.addEventListener('input', () => {
    let visible = 0;
    document.querySelectorAll('.adb-library tbody tr').forEach(row => {
      row.hidden = !row.textContent.toLowerCase().includes(search.value.toLowerCase());
      if (!row.hidden) visible++;
    });
    document.getElementById('adb-no-results').hidden = visible > 0;
  });
  const form = document.getElementById('adb-editor');
  if (!form) return;
  const field = key => form.elements.namedItem(`profile[${key}]`);
  const status = document.getElementById('adb-preview-status');
  const schemaStatus = document.getElementById('adb-schema-status');
  const frame = document.getElementById('adb-preview');
  let dirty = false, timer, request = 0, schemaRequest = 0, tables = [], schemaBase = '';
  let submitting = false;
  const send = async (action, data) => {
    data.set('action', action); data.set('nonce', adbEditor.nonce);
    const response = await fetch(adbEditor.ajax, {method:'POST', body:new URLSearchParams(data), credentials:'same-origin'});
    const result = await response.json();
    if (!result.success) throw new Error(result.data?.message || 'Request failed. Please try again.');
    return result.data;
  };
  function visibility() {
    const layout = field('layout').value;
    const link = field('link_mode');
    [...link.options].forEach(option => {
      option.hidden = (option.value === 'whole' && layout !== 'bullet') || (option.value === 'button' && layout === 'bullet');
      option.disabled = option.hidden;
    });
    if (link.selectedOptions[0].disabled) link.value = 'title';
    const visible = {bullet:layout === 'bullet', visual:layout !== 'bullet', cards:layout === 'cards', button:link.value === 'button', 'date-limit':field('limit_enabled').checked};
    form.querySelectorAll('[data-show]').forEach(node => {node.hidden = !visible[node.dataset.show];});
    const start = field('display_start'), end = field('display_end');
    end.min = start.value;
    end.setCustomValidity(start.value && end.value && end.value < start.value ? 'Expiry must be on or after the start date.' : '');
  }
  function markDirty() {
    dirty = true;
    document.getElementById('adb-save-status').textContent = 'Unsaved changes';
  }
  async function preview() {
    const seq = ++request;
    status.textContent = 'Updating preview…';
    try {
      const data = await send('adb_preview', new FormData(form));
      if (seq !== request) return;
      frame.srcdoc = '<!doctype html><html><head><meta name="viewport" content="width=device-width,initial-scale=1"><style>body{margin:20px;font:16px/1.5 system-ui,sans-serif}a{pointer-events:none}</style></head><body>' + data.html + '</body></html>';
      status.textContent = data.message;
    } catch (error) {
      if (seq !== request) return;
      status.textContent = error.message;
      frame.srcdoc = '<!doctype html><p style="font:16px system-ui;padding:20px">Preview unavailable. See the message above.</p>';
    }
  }
  function queuePreview() { clearTimeout(timer); timer = setTimeout(preview, 650); }
  function replaceSource(key, options) {
    const old = field(key), current = old.value;
    const select = document.createElement('select'); select.id = old.id; select.name = old.name;
    select.add(new Option(key === 'view' ? 'All records (no view)' : 'Choose a table', ''));
    options.forEach(o => select.add(new Option(o.name, o.name === current ? o.name : o.id)));
    const match = options.find(o => o.id === current || o.name === current);
    if (match) select.value = match.name === current ? current : match.id;
    else if (current) { select.add(new Option(`${current} (saved; not found)`, current)); select.value = current; }
    old.replaceWith(select);
  }
  function tableLink(table) {
    const link = document.getElementById('adb-table-link');
    const base = field('base_id').value.trim();
    link.hidden = !table || !/^app[A-Za-z0-9]+$/.test(base) || !/^tbl[A-Za-z0-9]+$/.test(table.id);
    if (!link.hidden) link.href = `https://airtable.com/${encodeURIComponent(base)}/${encodeURIComponent(table.id)}`;
  }
  function mapTable() {
    if (schemaBase !== field('base_id').value.trim()) return;
    const table = tables.find(t => t.id === field('table').value || t.name === field('table').value);
    tableLink(table);
    if (!table) { schemaStatus.textContent = 'Choose one of the tables in this base.'; return; }
    replaceSource('view', table.views || []);
    let missing = 0;
    form.querySelectorAll('[data-mapping]').forEach(row => {
      const key = row.dataset.mapping, select = field(key), current = select.value;
      const date = key === 'start' || key === 'end';
      // Include date formulas/lookups only when Airtable describes a date result.
      const dateTypes = ['date','dateTime','createdTime','lastModifiedTime'];
      const fields = (table.fields || []).filter(f => !date || dateTypes.includes(f.type) || dateTypes.includes(f.options?.result?.type));
      select.replaceChildren(new Option('Don’t show / not mapped', ''));
      fields.forEach(f => select.add(new Option(`${f.name} · ${f.type}`, f.name)));
      select.classList.remove('adb-missing');
      if (current && !fields.some(f => f.name === current)) {
        select.add(new Option(`${current} (saved; unavailable${date ? ' or not a date field' : ''})`, current));
        select.classList.add('adb-missing'); missing++;
      }
      select.value = current;
    });
    schemaStatus.textContent = `${table.fields.length} fields loaded from ${table.name}.` + (missing ? ` ${missing} saved mappings need checking; choose a field or “Don’t show”.` : '');
  }
  async function loadFields() {
    const base = field('base_id').value.trim(), seq = ++schemaRequest;
    const data = new FormData(); data.set('base_id',base);
    schemaStatus.textContent = 'Loading table and field names…';
    try {
      const result = await send('adb_schema',data);
      if (seq !== schemaRequest || base !== field('base_id').value.trim()) return;
      tables = result.tables; schemaBase = base;
      replaceSource('table',tables); mapTable();
    } catch(error) { if (seq === schemaRequest) schemaStatus.textContent = error.message; }
  }
  form.addEventListener('input', event => {
    markDirty(); visibility();
    if (event.target === field('base_id')) {
      schemaRequest++; tables = []; schemaBase = ''; tableLink(null);
      ['table','view'].forEach(key => {const old = field(key); if(old.tagName === 'SELECT') {const input = document.createElement('input'); input.id = old.id; input.name = old.name; input.value = old.value; old.replaceWith(input);}});
      form.querySelectorAll('[data-mapping] select').forEach(select => {const current = select.value; select.replaceChildren(new Option('Don’t show / not mapped','')); if(current) {select.add(new Option(current + ' (saved; reload fields)',current)); select.value = current;}});
      schemaStatus.textContent = 'Base changed. Load tables & fields again before selecting mappings.';
    }
    queuePreview();
  });
  form.addEventListener('change', event => {
    if (event.target === field('table')) mapTable();
    markDirty(); visibility(); queuePreview();
  });
  form.addEventListener('submit', () => {submitting = true;});
  window.addEventListener('beforeunload', event => {if (dirty && !submitting) {event.preventDefault(); event.returnValue = '';}});
  document.getElementById('adb-load-fields').addEventListener('click',loadFields);
  document.getElementById('adb-preview-refresh').addEventListener('click',() => {clearTimeout(timer); preview();});
  ['desktop','mobile'].forEach(size => document.getElementById(`adb-${size}`).addEventListener('click', () => {
    frame.classList.toggle('adb-mobile', size === 'mobile');
    ['desktop','mobile'].forEach(s => document.getElementById(`adb-${s}`).setAttribute('aria-pressed',String(s === size)));
  }));
  const deletion = document.querySelector('#adb-delete form');
  if(deletion) deletion.addEventListener('submit',event => {if(!confirm('Delete this display? Every embed using its shortcode will become empty.')) event.preventDefault();});
  visibility(); preview();
  if (field('base_id').value && field('table').value) loadFields();
})();
