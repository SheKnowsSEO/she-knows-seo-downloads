<?php
/**
 * Plugin Name: Airtable Display Builder
 * Description: Secure, cache-friendly Airtable displays for WordPress.
 * Version: 0.3.0
 * Author: She Knows SEO
 */
if ( ! defined( 'ABSPATH' ) ) { exit; }

define( 'ADB_VERSION', '0.3.0' );
define( 'ADB_OPTION', 'adb_settings' );
define( 'ADB_PROFILES_OPTION', 'adb_profiles' );

function adb_defaults() {
    return array(
        'token' => '', 'base_id' => '', 'table' => '', 'view' => '',
        'title' => 'Product Name', 'seller' => 'Seller', 'deal' => 'Deal',
        'description' => 'Description', 'thoughts' => 'Our Thoughts',
        'image' => 'Image', 'url' => 'Deal URL', 'start' => 'Start Date',
        'end' => 'Expiration Date', 'layout' => 'directory',
        'limit_enabled' => 0, 'days' => 365, 'button_label' => 'View offer',
        'heading_size' => '1.7rem', 'background' => '#ffffff',
        'border' => '#f0e68c', 'button_background' => '#295CFF',
        'button_text' => '#ffffff', 'heading_colour' => '#10245b', 'columns' => 4,
        'bullet_template' => '{title} — {seller} — {deal}',
        'link_mode' => 'title', 'border_width' => 3, 'border_radius' => 11,
        'display_start' => '', 'display_end' => '',
    );
}
function adb_settings() { return wp_parse_args( (array) get_option( ADB_OPTION, array() ), adb_defaults() ); }
function adb_profile_defaults() {
    $defaults = adb_defaults();
    unset( $defaults['token'] );
    return $defaults;
}
function adb_profile_slug( $name ) {
    $slug = sanitize_title( $name );
    return $slug ? $slug : 'display';
}
function adb_profiles() {
    $profiles = get_option( ADB_PROFILES_OPTION, null );
    if ( is_array( $profiles ) && ! empty( $profiles ) ) { return $profiles; }
    $legacy = adb_settings();
    $profile = $legacy;
    unset( $profile['token'] );
    $profile['name'] = 'Original display';
    $profiles = array( 'default' => wp_parse_args( $profile, adb_profile_defaults() ) );
    update_option( ADB_PROFILES_OPTION, $profiles, false );
    return $profiles;
}
function adb_profile( $id = '' ) {
    $profiles = adb_profiles();
    if ( $id && isset( $profiles[ $id ] ) ) { $p = $profiles[$id]; if ( !isset($p['link_mode']) ) { $p['link_mode'] = 'bullet' === ($p['layout'] ?? '') ? 'whole' : 'button'; } return wp_parse_args( $p, adb_profile_defaults() ); }
    $first = reset( $profiles );
    return wp_parse_args( is_array( $first ) ? $first : array(), adb_profile_defaults() );
}
function adb_profile_id( $id = '' ) {
    $profiles = adb_profiles();
    if ( $id && isset( $profiles[ $id ] ) ) { return $id; }
    $keys = array_keys( $profiles );
    return $keys ? (string) $keys[0] : 'default';
}
function adb_clean_profile_id( $id ) { return preg_replace( '/[^A-Za-z0-9_-]/', '', (string) $id ); }
function adb_encrypt( $value ) { return $value ? base64_encode( openssl_encrypt( $value, 'aes-256-cbc', wp_salt( 'auth' ), 0, substr( hash( 'sha256', wp_salt( 'secure_auth' ), true ), 0, 16 ) ) ) : ''; }
function adb_decrypt( $value ) { return $value ? (string) openssl_decrypt( base64_decode( $value ), 'aes-256-cbc', wp_salt( 'auth' ), 0, substr( hash( 'sha256', wp_salt( 'secure_auth' ), true ), 0, 16 ) ) : ''; }

add_action( 'admin_menu', function() { add_menu_page( 'Airtable Displays', 'Airtable Displays', 'manage_options', 'airtable-display-builder', 'adb_admin_page', 'dashicons-screenoptions', 90 ); } );
add_action( 'admin_init', function() { register_setting( 'adb_settings_group', ADB_OPTION, array( 'sanitize_callback' => 'adb_sanitize_settings' ) ); } );
function adb_sanitize_settings( $raw ) {
    $old = adb_settings(); $out = adb_defaults();
    foreach ( array( 'base_id','table','view','title','seller','deal','description','thoughts','image','url','start','end','button_label','layout','days','heading_size','bullet_template' ) as $key ) { $out[$key] = isset( $raw[$key] ) ? sanitize_text_field( $raw[$key] ) : $out[$key]; }
    $out['columns'] = isset( $raw['columns'] ) ? max( 1, min( 5, absint( $raw['columns'] ) ) ) : $out['columns'];
    foreach ( array( 'background','border','button_background','button_text','heading_colour' ) as $key ) { $out[$key] = isset( $raw[$key] ) ? sanitize_hex_color( $raw[$key] ) : $out[$key]; }
    $out['limit_enabled'] = ! empty( $raw['limit_enabled'] ) ? 1 : 0;
    $out['token'] = ! empty( $raw['token'] ) ? adb_encrypt( sanitize_text_field( $raw['token'] ) ) : ( $old['token'] ?? '' );
    return $out;
}
require_once __DIR__ . '/admin.php';
add_action( 'admin_post_adb_save_token', function() {
    if ( ! current_user_can( 'manage_options' ) ) { wp_die( 'You do not have permission to save this token.' ); }
    check_admin_referer( 'adb_save_token' );
    $settings = adb_settings();
    if ( ! empty( $_POST['token'] ) ) { $settings['token'] = adb_encrypt( sanitize_text_field( wp_unslash( $_POST['token'] ) ) ); update_option( ADB_OPTION, $settings, false ); }
    wp_safe_redirect( admin_url( 'admin.php?page=airtable-display-builder' ) ); exit;
} );
add_action( 'admin_post_adb_save_profile', function() {
    if ( ! current_user_can( 'manage_options' ) ) { wp_die( 'You do not have permission to save this display.' ); }
    check_admin_referer( 'adb_save_profile' );
    $id = adb_clean_profile_id( wp_unslash( $_POST['profile_id'] ?? '' ) ); $profiles = adb_profiles();
    if ( ! $id || ! isset( $profiles[ $id ] ) ) { wp_die( 'Display not found.' ); }
    $raw = isset( $_POST['profile'] ) && is_array( $_POST['profile'] ) ? wp_unslash( $_POST['profile'] ) : array();
    $out = adb_clean_profile( $raw );
    $error = adb_profile_error( $out );
    if ( $error ) { wp_die( esc_html( $error ), 'Check display settings', array( 'back_link' => true ) ); }
    $profiles[ $id ] = $out; update_option( ADB_PROFILES_OPTION, $profiles, false );
    do_action( 'adb_display_updated', $id );
    if ( function_exists( 'rocket_clean_domain' ) ) { rocket_clean_domain(); }
    wp_safe_redirect( admin_url( 'admin.php?page=airtable-display-builder&display='.rawurlencode( $id ).'&saved=1' ) ); exit;
} );
add_action( 'admin_post_adb_new_profile', function() {
    if ( ! current_user_can( 'manage_options' ) ) { wp_die( 'You do not have permission to create a display.' ); }
    check_admin_referer( 'adb_new_profile' ); $profiles = adb_profiles(); $id = 'display-'.strtolower( wp_generate_password( 6, false, false ) ); $source_id = adb_clean_profile_id( wp_unslash( $_POST['source_profile_id'] ?? '' ) ); $source = isset( $profiles[ $source_id ] ) ? adb_profile($source_id) : adb_profile_defaults(); $profiles[ $id ] = array_merge( adb_profile_defaults(), $source, array( 'name'=> isset( $profiles[$source_id] ) ? ( $source['name'].' (copy)' ) : 'New display' ) ); update_option( ADB_PROFILES_OPTION, $profiles, false );
    wp_safe_redirect( admin_url( 'admin.php?page=airtable-display-builder&display='.rawurlencode( $id ) ) ); exit;
} );
add_action( 'admin_post_adb_delete_profile', function() {
    if ( ! current_user_can( 'manage_options' ) ) { wp_die( 'You do not have permission to delete a display.' ); }
    check_admin_referer( 'adb_delete_profile' ); $id = adb_clean_profile_id( wp_unslash( $_POST['profile_id'] ?? '' ) ); $profiles = adb_profiles(); if ( count( $profiles ) > 1 ) { unset( $profiles[ $id ] ); update_option( ADB_PROFILES_OPTION, $profiles, false ); }
    wp_safe_redirect( admin_url( 'admin.php?page=airtable-display-builder' ) ); exit;
} );
add_action( 'admin_post_adb_test_connection', function() {
    if ( ! current_user_can( 'manage_options' ) ) { wp_die( 'You do not have permission to test this connection.' ); }
    check_admin_referer( 'adb_test_connection' );
    $s = adb_profile( adb_clean_profile_id( wp_unslash( $_POST['profile_id'] ?? '' ) ) );
    delete_transient( 'adb_snapshot_' . md5( $s['base_id'].'|'.$s['table'].'|'.$s['view'] ) );
    adb_fetch( $s );
    wp_safe_redirect( admin_url( 'admin.php?page=airtable-display-builder&display='.rawurlencode( adb_clean_profile_id( wp_unslash( $_POST['profile_id'] ?? '' ) ) ) ) );
    exit;
} );
function adb_text_row( $key, $label, $s ) { adb_input_row( $key, $label, $s[$key] ?? '', 'text' ); }
function adb_input_row( $key, $label, $value, $type='text' ) { echo '<tr><th scope="row"><label for="adb-'.esc_attr($key).'">'.esc_html($label).'</label></th><td><input id="adb-'.esc_attr($key).'" name="'.esc_attr(ADB_OPTION).'['.esc_attr($key).']" type="'.esc_attr($type).'" value="'.esc_attr($value).'" class="regular-text"></td></tr>'; }
function adb_checkbox_row( $key, $label, $s ) { echo '<tr><th scope="row">'.esc_html($label).'</th><td><label><input type="checkbox" name="'.esc_attr(ADB_OPTION).'['.esc_attr($key).']" value="1" '.checked( !empty($s[$key]), true, false ).'> Only show records inside the selected date window</label></td></tr>'; }
function adb_select_row( $key, $label, $value, $options ) { echo '<tr><th scope="row">'.esc_html($label).'</th><td><select name="'.esc_attr(ADB_OPTION).'['.esc_attr($key).']">'; foreach($options as $v=>$l) echo '<option value="'.esc_attr($v).'" '.selected($value,$v,false).'>'.esc_html($l).'</option>'; echo '</select></td></tr>'; }

function adb_fetch( $profile = array() ) {
    $s = wp_parse_args( is_array( $profile ) ? $profile : array(), adb_profile_defaults() ); $global = adb_settings(); if ( empty( $global['token'] ) || empty( $s['base_id'] ) || empty( $s['table'] ) ) { update_option( 'adb_last_status', array( 'checked'=>current_time('mysql'), 'code'=>'not configured', 'records'=>0, 'message'=>'Add a token, base, and table.' ), false ); return array(); }
    $plain_token = adb_decrypt( $global['token'] );
    $token_ready = is_string( $plain_token ) && '' !== $plain_token;
    $token_shape = $token_ready && 0 === strpos( $plain_token, 'pat' ) && strlen( $plain_token ) >= 30;
    $credential_status = $token_ready ? ( $token_shape ? 'decrypted and has the expected Airtable PAT shape' : 'decrypted, but does not have the expected Airtable PAT shape' ) : 'could not be decrypted';
    if ( ! $token_ready ) { update_option( 'adb_last_status', array( 'checked'=>current_time('mysql'), 'code'=>'credential error', 'records'=>0, 'message'=>'The saved credential could not be decrypted by WordPress.', 'credential'=>$credential_status ), false ); return array(); }
    $cache_key = 'adb_snapshot_' . md5( $s['base_id'].'|'.$s['table'].'|'.$s['view'] ); $cached = get_transient( $cache_key ); if ( is_array( $cached ) ) { return $cached; }
    $url = 'https://api.airtable.com/v0/' . rawurlencode( $s['base_id'] ) . '/' . rawurlencode( $s['table'] ); if ( $s['view'] ) $url = add_query_arg( 'view', $s['view'], $url );
    $records = array(); $offset = ''; $pages = 0;
    do {
        if ( $pages++ >= 50 ) { update_option( 'adb_last_status', array( 'checked'=>current_time('mysql'), 'code'=>'limit', 'message'=>'This table exceeds the 5,000-record limit. Choose a smaller Airtable view.' ), false ); return array(); }
        if ( $pages > 1 ) { usleep( 220000 ); }
        $request_url = $offset ? add_query_arg( 'offset', $offset, $url ) : $url;
        $response = wp_remote_get( $request_url, array( 'timeout'=>15, 'redirection'=>0, 'headers'=>array( 'Authorization'=>'Bearer '.$plain_token, 'Accept'=>'application/json' ) ) );
        if ( is_wp_error($response) ) { update_option( 'adb_last_status', array( 'checked'=>current_time('mysql'), 'code'=>'request error', 'records'=>0, 'message'=>$response->get_error_message(), 'credential'=>$credential_status ), false ); return is_array($cached) ? $cached : array(); }
        $code = wp_remote_retrieve_response_code($response);
        if ( 200 !== $code ) { $body = json_decode( wp_remote_retrieve_body($response), true ); $message = is_array($body) && !empty($body['error']['message']) ? $body['error']['message'] : 'Airtable did not return a successful response.'; update_option( 'adb_last_status', array( 'checked'=>current_time('mysql'), 'code'=>$code, 'records'=>0, 'message'=>$message, 'credential'=>$credential_status ), false ); return is_array($cached) ? $cached : array(); }
        $data = json_decode( wp_remote_retrieve_body($response), true );
        if ( ! empty($data['records']) && is_array($data['records']) ) $records = array_merge($records, $data['records']);
        $offset = !empty($data['offset']) ? $data['offset'] : '';
    } while ( $offset );
    set_transient( $cache_key, $records, 300 ); update_option( 'adb_last_good_snapshot', time(), false ); update_option( 'adb_last_status', array( 'checked'=>current_time('mysql'), 'code'=>200, 'records'=>count($records), 'message'=>'Connection successful.', 'credential'=>$credential_status ), false ); return $records;
}
function adb_value( $fields, $key ) { $v = $fields[$key] ?? ''; if ( is_array($v) ) { if ( isset($v[0]['url']) ) return (string)$v[0]['url']; if ( isset($v[0]['name']) ) return (string)$v[0]['name']; return isset($v[0]) && is_scalar($v[0]) ? (string)$v[0] : ''; } return is_scalar($v) ? (string)$v : ''; }
function adb_bullet_text( $template, $values ) {
    $tokens = array();
    foreach ( array( 'title', 'seller', 'deal', 'description', 'thoughts' ) as $key ) { $tokens['{'.$key.'}'] = esc_html( $values[$key] ?? '' ); }
    return strtr( esc_html( $template ), $tokens );
}
function adb_render( $atts = array() ) {
    $atts = shortcode_atts( array( 'display' => '', 'layout' => '' ), $atts, 'airtable_display' );
    $id = adb_clean_profile_id( $atts['display'] );
    if ( $id && ! isset( adb_profiles()[$id] ) ) { return ''; }
    $id = adb_profile_id( $id ); $s = adb_profile( $id );
    if ( in_array( $atts['layout'], array( 'directory', 'bullet', 'cards' ), true ) ) { $s['layout'] = $atts['layout']; }
    return adb_render_records( $s, adb_fetch( $s ), $id );
}
function adb_render_records( $s, $records, $profile_id = 'preview' ) {
    $s = wp_parse_args( $s, adb_profile_defaults() );
    $today = current_time( 'Y-m-d' );
    if ( ( $s['display_start'] && $today < $s['display_start'] ) || ( $s['display_end'] && $today > $s['display_end'] ) ) { return ''; }
    $layout = $s['layout']; $now = time(); $items_tag = 'bullet' === $layout ? 'ul' : 'div';
    $scope = 'adb-profile-'.sanitize_html_class( $profile_id );
    $html = '<style>'.adb_profile_css( $s, $scope ).'</style><section class="adb-display '.esc_attr( $scope ).' adb-layout-'.esc_attr($layout).'" aria-label="'.esc_attr( $s['name'] ?? 'Airtable display' ).'"><'.$items_tag.' class="adb-items">';
    foreach ( $records as $record ) { $f = $record['fields'] ?? array(); $title=adb_value($f,$s['title']); $url=adb_value($f,$s['url']); if(!$title) continue; $start=adb_value($f,$s['start']); $end=adb_value($f,$s['end']); if($s['limit_enabled']) { $ts=adb_record_date($start); $te=adb_record_date($end, true); if($ts && $ts > $now) continue; if($te && $te < $now) continue; if(!$end && $ts && $ts < ($now - absint($s['days'])*DAY_IN_SECONDS)) continue; }
        $img=adb_value($f,$s['image']); $seller=adb_value($f,$s['seller']); $deal=adb_value($f,$s['deal']); $desc=adb_value($f,$s['description']); $thoughts=adb_value($f,$s['thoughts']);
        if ( 'bullet' === $layout ) {
            $values = array( 'title'=>$title, 'seller'=>$seller, 'deal'=>$deal, 'description'=>$desc, 'thoughts'=>$thoughts );
            $tokens = array();
            foreach ( $values as $key=>$value ) {
                $text = esc_html( $value );
                if ( 'title' === $key && 'title' === $s['link_mode'] && esc_url( $url ) ) { $text = adb_link( $url, $text, 'adb-bullet-link' ); }
                $tokens['{'.$key.'}'] = $text;
            }
            $text = strtr( esc_html( $s['bullet_template'] ), $tokens );
            if ( 'whole' === $s['link_mode'] && esc_url( $url ) ) { $text = adb_link( $url, $text, 'adb-bullet-link' ); }
            $html .= '<li class="adb-item">'.$text.'</li>'; continue;
        }
        $has_image = $img && esc_url( $img, array( 'http', 'https' ) );
        $item='<article class="adb-item'.( $has_image ? '' : ' adb-no-image' ).'">';
        if ( $has_image ) { $item.='<img class="adb-image" src="'.esc_url($img).'" alt="" loading="lazy">'; }
        $title_html = esc_html( $title );
        if ( 'title' === $s['link_mode'] && esc_url( $url ) ) { $title_html = adb_link( $url, $title_html, 'adb-title-link' ); }
        $item.='<div class="adb-copy"><h3 class="adb-title">'.$title_html.'</h3>';
        if($seller) $item.='<p class="adb-seller">'.esc_html($seller).'</p>';
        if($deal) $item.='<p class="adb-deal"><strong>'.esc_html($deal).'</strong></p>';
        if($desc) $item.='<p class="adb-description">'.esc_html($desc).'</p>';
        if($thoughts) $item.='<p class="adb-thoughts"><strong>Our thoughts:</strong> '.esc_html($thoughts).'</p>';
        if ( $url && 'button' === $s['link_mode'] ) { $item .= adb_link( $url, esc_html( $s['button_label'] ), 'adb-button' ); }
        $item .= '</div></article>'; $html .= $item;
    }
    return $html.'</'.$items_tag.'></section>';
}
add_shortcode( 'airtable_display', 'adb_render' );
function adb_link( $url, $text, $class ) {
    return '<a class="'.esc_attr($class).'" href="'.esc_url($url).'" target="_blank" rel="nofollow noopener noreferrer">'.$text.'</a>';
}
function adb_record_date( $value, $end = false ) {
    if ( ! $value ) { return 0; }
    try { $date = new DateTimeImmutable( $value, wp_timezone() ); }
    catch ( Exception $e ) { return 0; }
    if ( preg_match( '/^\d{4}-\d{2}-\d{2}$/', $value ) && $end ) { $date = $date->setTime(23,59,59); }
    return $date->getTimestamp();
}
function adb_profile_css( $s, $scope ) {
    $selector = '.'.sanitize_html_class( $scope );
    $css = file_get_contents( __DIR__.'/assets/display.css' );
    $vars = '--adb-bg:'.sanitize_hex_color($s['background']).';--adb-border:'.sanitize_hex_color($s['border']).';--adb-button:'.sanitize_hex_color($s['button_background']).';--adb-button-text:'.sanitize_hex_color($s['button_text']).';--adb-heading:'.sanitize_hex_color($s['heading_colour']).';--adb-heading-size:'.adb_heading_size($s['heading_size']).';--adb-columns:'.max(1,min(5,absint($s['columns']))).';--adb-medium-columns:'.min(2,max(1,(int)$s['columns'])).';--adb-border-width:'.max(0,min(12,(int)$s['border_width'])).'px;--adb-radius:'.max(0,min(48,(int)$s['border_radius'])).'px;';
    return $selector.'{'.$vars.'}'.str_replace( '.adb-scope', $selector, $css );
}
