<?php
if ( ! defined( 'ABSPATH' ) ) { exit; }

function adb_heading_size( $value ) {
    return preg_match( '/^(?:[0-9]+(?:\.[0-9]+)?)(?:px|rem|em)$/', (string)$value ) ? $value : '1.7rem';
}
function adb_clean_profile( $raw ) {
    $out = adb_profile_defaults();
    foreach ( array_keys( $out ) as $key ) {
        if ( isset($raw[$key]) && is_scalar($raw[$key]) ) { $out[$key] = sanitize_text_field($raw[$key]); }
    }
    $out['name'] = isset($raw['name']) && is_scalar($raw['name']) ? sanitize_text_field($raw['name']) : 'Untitled display';
    if ( !$out['name'] ) { $out['name'] = 'Untitled display'; }
    $out['layout'] = in_array($out['layout'], array('bullet','cards','directory'), true) ? $out['layout'] : 'directory';
    $out['link_mode'] = in_array($out['link_mode'], array('title','whole','button','none'), true) ? $out['link_mode'] : 'title';
    if ( 'bullet' === $out['layout'] && 'button' === $out['link_mode'] ) { $out['link_mode'] = 'title'; }
    if ( 'bullet' !== $out['layout'] && 'whole' === $out['link_mode'] ) { $out['link_mode'] = 'title'; }
    foreach ( array('background','border','button_background','button_text','heading_colour') as $key ) { $out[$key] = sanitize_hex_color($out[$key]) ?: adb_defaults()[$key]; }
    $out['heading_size'] = adb_heading_size($out['heading_size']);
    foreach ( array('columns'=>array(1,5), 'border_width'=>array(0,12), 'border_radius'=>array(0,48), 'days'=>array(1,36500)) as $key=>$bounds ) { $out[$key] = max($bounds[0],min($bounds[1],(int)$out[$key])); }
    $out['limit_enabled'] = empty($raw['limit_enabled']) ? 0 : 1;
    return $out;
}
function adb_profile_error( $s ) {
    foreach ( array('display_start','display_end') as $key ) {
        if ( !$s[$key] ) { continue; }
        $date = DateTimeImmutable::createFromFormat('!Y-m-d', $s[$key]);
        if ( !$date || $date->format('Y-m-d') !== $s[$key] ) { return 'Choose a valid start and expiry date using the calendar controls.'; }
    }
    if ( $s['display_start'] && $s['display_end'] && $s['display_start'] > $s['display_end'] ) { return 'The expiry date must be on or after the start date.'; }
    return '';
}
function adb_admin_url( $id = '' ) { return admin_url('admin.php?page=airtable-display-builder'.($id ? '&display='.rawurlencode($id) : '')); }
function adb_admin_assets() {
    wp_enqueue_style('adb-admin', plugins_url('assets/admin.css',__FILE__), array(), ADB_VERSION);
    wp_enqueue_script('adb-admin', plugins_url('assets/admin.js',__FILE__), array(), ADB_VERSION, true);
    wp_localize_script('adb-admin','adbEditor',array('ajax'=>admin_url('admin-ajax.php'),'nonce'=>wp_create_nonce('adb_editor')));
}
add_action('admin_enqueue_scripts',function($hook){ if ('toplevel_page_airtable-display-builder' === $hook) { adb_admin_assets(); } });
function adb_action_form( $action, $label, $id = '', $key = 'profile_id', $class = 'secondary' ) {
    echo '<form method="post" action="'.esc_url(admin_url('admin-post.php')).'" class="adb-inline">';
    wp_nonce_field($action); echo '<input type="hidden" name="action" value="'.esc_attr($action).'"><input type="hidden" name="'.esc_attr($key).'" value="'.esc_attr($id).'">';
    submit_button($label,$class,'submit',false); echo '</form>';
}
function adb_control( $key, $label, $s, $type = 'text', $options = null, $show = '' ) {
    echo '<div class="adb-control"'.($show ? ' data-show="'.esc_attr($show).'"' : '').'><label for="adb-'.esc_attr($key).'">'.esc_html($label).'</label>';
    if ( is_array($options) ) {
        echo '<select id="adb-'.esc_attr($key).'" name="profile['.esc_attr($key).']">';
        foreach($options as $value=>$text) { echo '<option value="'.esc_attr($value).'" '.selected((string)$s[$key],(string)$value,false).'>'.esc_html($text).'</option>'; } echo '</select>';
    } else {
        $extra = '';
        if ('number' === $type) { $bounds = array('columns'=>array(1,5),'days'=>array(1,36500),'border_width'=>array(0,12),'border_radius'=>array(0,48)); $b=$bounds[$key]??array(0,100); $extra=' min="'.$b[0].'" max="'.$b[1].'" step="1"'; }
        echo '<input id="adb-'.esc_attr($key).'" name="profile['.esc_attr($key).']" type="'.esc_attr($type).'" value="'.esc_attr($s[$key]??'').'"'.$extra.'>';
    }
    echo '</div>';
}
function adb_admin_page() {
    if (!current_user_can('manage_options')) { return; }
    $profiles=adb_profiles(); $id=isset($_GET['display']) ? adb_clean_profile_id(wp_unslash($_GET['display'])) : '';
    echo '<div class="wrap adb-admin"><h1>Airtable Displays</h1>';
    if (!$id || !isset($profiles[$id])) {
        echo '<div class="adb-page-head"><div><h2>All displays</h2><p>Create a display once. Reuse it in any post or page.</p></div>';
        adb_action_form('adb_new_profile','Add new display','','source_profile_id','primary'); echo '</div>';
        echo '<label for="adb-search">Find a display</label> <input id="adb-search" type="search" placeholder="Search by name or source"><table class="wp-list-table widefat fixed striped adb-library"><thead><tr><th>Display name</th><th>Layout</th><th>Airtable source</th><th>Shortcode</th></tr></thead><tbody>';
        foreach($profiles as $pid=>$profile) {
            echo '<tr><td><strong><a href="'.esc_url(adb_admin_url($pid)).'">'.esc_html($profile['name']??$pid).'</a></strong><div class="row-actions"><a href="'.esc_url(adb_admin_url($pid)).'">Edit &amp; preview</a></div></td><td>'.esc_html(ucfirst($profile['layout']??'directory')).'</td><td>'.esc_html($profile['table']??'Not connected').'</td><td><code>'.esc_html('[airtable_display display="'.$pid.'"]').'</code></td></tr>';
        }
        echo '</tbody></table><p id="adb-no-results" hidden>No displays match your search.</p>';
        adb_connection_panel(); echo '</div>'; return;
    }
    $s=adb_profile($id);
    echo '<p><a href="'.esc_url(adb_admin_url()).'">&larr; All displays</a></p>';
    if (!empty($_GET['saved'])) { echo '<div class="notice notice-success"><p>Display saved. Every use of this shortcode uses these settings. Cached pages may need refreshing.</p></div>'; }
    echo '<div class="adb-page-head"><div><h2>Edit: '.esc_html($s['name']).'</h2><code>'.esc_html('[airtable_display display="'.$id.'"]').'</code></div>';
    adb_action_form('adb_new_profile','Duplicate as template',$id,'source_profile_id'); echo '</div>';
    echo '<div class="adb-workspace"><form id="adb-editor" method="post" action="'.esc_url(admin_url('admin-post.php')).'">';
    wp_nonce_field('adb_save_profile'); echo '<input type="hidden" name="action" value="adb_save_profile"><input type="hidden" name="profile_id" value="'.esc_attr($id).'">';
    echo '<section class="adb-panel"><h2>1. Name &amp; source</h2>';
    adb_control('name','Display name',$s); adb_control('base_id','Airtable base ID',$s); adb_control('table','Table name or ID',$s); adb_control('view','View (optional)',$s);
    echo '<button type="button" class="button" id="adb-load-fields">Load tables &amp; fields</button> <a id="adb-table-link" target="_blank" rel="noopener noreferrer" hidden>Open table in Airtable ↗</a><p id="adb-schema-status" role="status">Load the source to choose its actual table, view and field names.</p></section>';
    echo '<section class="adb-panel"><h2>2. Choose a layout</h2><div class="adb-layout-picker">';
    foreach(array('bullet'=>'Bullet list','directory'=>'Directory','cards'=>'Cards') as $value=>$label) {
        echo '<label class="adb-layout-choice"><input type="radio" name="profile[layout]" value="'.$value.'" '.checked($s['layout'],$value,false).'><span class="adb-mini adb-mini-'.$value.'" aria-hidden="true"><i></i><i></i><i></i></span><strong>'.$label.'</strong><small>'.esc_html(array('bullet'=>'Simple lines of text','directory'=>'Rows with optional images','cards'=>'A flexible card grid')[$value]).'</small></label>';
    }
    echo '</div></section><section class="adb-panel"><h2>3. Map your content</h2><p>Select a field from your table, or “Don’t show”. Existing mappings stay in place until you change them.</p>';
    foreach(array('title'=>'Title / blog post name','seller'=>'Seller / author','deal'=>'Offer / supporting text','description'=>'Description','thoughts'=>'Our thoughts','image'=>'Image','url'=>'Link URL','start'=>'Record start date field','end'=>'Record expiry date field') as $key=>$label) {
        echo '<div class="adb-control" data-mapping="'.$key.'"'.('image'===$key?' data-show="visual"':'').'><label for="adb-'.$key.'">'.$label.'</label><select id="adb-'.$key.'" name="profile['.$key.']"><option value="">Don’t show / not mapped</option>';
        if($s[$key]) { echo '<option value="'.esc_attr($s[$key]).'" selected>'.esc_html($s[$key]).' (saved mapping)</option>'; }
        echo '</select></div>';
    }
    echo '<p class="description">Record dates come from Airtable date fields. Edit those dates in Airtable using “Open table”. Display-wide calendar dates are below.</p></section>';
    echo '<section class="adb-panel"><h2>4. Text, links &amp; style</h2>';
    adb_control('bullet_template','Text for each bullet',$s,'text',null,'bullet');
    echo '<p data-show="bullet">Use {title}, {seller}, {deal}, {description}, {thoughts}. Example: {title} by {seller}</p>';
    adb_control('link_mode','What should be linked?',$s,'text',array('title'=>'Title only','whole'=>'Whole bullet line','button'=>'Button only','none'=>'No link'));
    adb_control('button_label','Button text',$s,'text',null,'button');
    adb_control('columns','Cards per row (desktop)',$s,'number',null,'cards');
    adb_control('heading_size','Heading size (e.g. 1.7rem or 24px)',$s,'text',null,'visual');
    adb_control('border_width','Border width in px (0 = no border)',$s,'number',null,'visual');
    adb_control('border_radius','Corner radius in px',$s,'number',null,'visual');
    foreach(array('background'=>'Background','border'=>'Border colour','heading_colour'=>'Heading colour','button_background'=>'Link / button colour','button_text'=>'Button text colour') as $key=>$label) { adb_control($key,$label,$s,'color',null,'button_text'===$key?'button':(in_array($key,array('background','border','heading_colour'),true)?'visual':'')); }
    echo '</section><section class="adb-panel"><h2>5. Dates &amp; visibility</h2><p>Leave the calendar dates blank to keep the display available. Dates use the WordPress site timezone; expiry includes the whole day.</p>';
    adb_control('display_start','Show this display from',$s,'date'); adb_control('display_end','Show this display until',$s,'date');
    echo '<label><input id="adb-limit" type="checkbox" name="profile[limit_enabled]" value="1" '.checked(!empty($s['limit_enabled']),true,false).'> Filter individual records by their mapped dates</label>';
    adb_control('days','Keep records without an expiry date for this many days',$s,'number',null,'date-limit');
    echo '</section><div class="adb-save"><button class="button button-primary button-large" type="submit">Save display everywhere</button><span id="adb-save-status" role="status">Previewing saved settings</span><p>Saving updates every embed of this display. It does not change the Airtable records.</p></div></form>';
    echo '<aside class="adb-preview-panel"><div class="adb-preview-head"><h2>Preview</h2><div><button class="button" type="button" id="adb-desktop" aria-pressed="true">Desktop</button> <button class="button" type="button" id="adb-mobile" aria-pressed="false">Mobile</button></div></div><p>Uses your mapped Airtable records. Changes here stay unsaved until you save the display.</p><button type="button" class="button" id="adb-preview-refresh">Refresh preview</button><p id="adb-preview-status" role="status">Loading preview…</p><iframe id="adb-preview" title="Display preview" sandbox=""></iframe><p class="description">Preview shows up to 12 matching records. Your WordPress theme may affect fonts and spacing.</p></aside></div>';
    echo '<details class="adb-management"><summary>Connection &amp; display management</summary>';
    adb_action_form('adb_test_connection','Refresh Airtable records',$id);
    if(count($profiles)>1) { echo '<div id="adb-delete">'; adb_action_form('adb_delete_profile','Delete display',$id); echo '<p>Existing embeds of a deleted display will become empty.</p></div>'; }
    echo '</details></div>';
}
function adb_connection_panel() {
    echo '<details class="adb-panel"><summary>Shared Airtable connection</summary><form method="post" action="'.esc_url(admin_url('admin-post.php')).'">';
    wp_nonce_field('adb_save_token'); echo '<input type="hidden" name="action" value="adb_save_token"><p><label for="adb-token">Personal Access Token</label></p><input id="adb-token" type="password" name="token" autocomplete="new-password" class="regular-text" placeholder="Leave blank to keep the saved token"><p>Needs data.records:read and schema.bases:read access to your base. The token stays on your WordPress server.</p>'; submit_button('Save connection','secondary'); echo '</form></details>';
}
function adb_editor_auth() {
    if (!current_user_can('manage_options')) { wp_send_json_error(array('message'=>'You cannot edit displays.'),403); }
    check_ajax_referer('adb_editor','nonce');
}
add_action('wp_ajax_adb_schema',function(){
    adb_editor_auth(); $base=sanitize_text_field(wp_unslash($_POST['base_id']??''));
    if (!preg_match('/^app[A-Za-z0-9]+$/',$base)) { wp_send_json_error(array('message'=>'Enter an Airtable base ID beginning with app.'),400); }
    $global=adb_settings(); $token=adb_decrypt($global['token']);
    if (!$token) { wp_send_json_error(array('message'=>'Save your Airtable token under All displays → Shared Airtable connection first.'),400); }
    $key='adb_schema_'.md5($base.'|'.$global['token']); $tables=get_transient($key);
    if (false===$tables) {
        $response=wp_remote_get('https://api.airtable.com/v0/meta/bases/'.rawurlencode($base).'/tables',array('timeout'=>15,'redirection'=>0,'headers'=>array('Authorization'=>'Bearer '.$token)));
        if (is_wp_error($response) || 200!==wp_remote_retrieve_response_code($response)) { wp_send_json_error(array('message'=>'Could not load fields. Check that the token has schema.bases:read and access to this base. Your saved mappings have been kept.'),400); }
        $body=json_decode(wp_remote_retrieve_body($response),true); $tables=$body['tables']??null;
        if (!is_array($tables)) { wp_send_json_error(array('message'=>'Airtable returned an invalid table list.'),502); }
        set_transient($key,$tables,300);
    }
    // Return schema only, never credentials or record values.
    wp_send_json_success(array('tables'=>$tables));
});
add_action('wp_ajax_adb_preview',function(){
    adb_editor_auth(); $raw=isset($_POST['profile'])&&is_array($_POST['profile'])?wp_unslash($_POST['profile']):array(); $s=adb_clean_profile($raw);
    $error=adb_profile_error($s); if($error) { wp_send_json_error(array('message'=>$error),400); }
    if(!$s['base_id']||!$s['table']) { wp_send_json_error(array('message'=>'Choose a base and table to preview your records.'),400); }
    $records=adb_fetch($s);
    $html=adb_render_records($s,$records,'preview');
    // Limit after filtering, so hidden/expired records do not consume preview slots.
    $html=adb_preview_limit($html,12);
    if (!preg_match('/<(?:li|article) class="adb-item/',$html)) { $diag=get_option('adb_last_status',array()); $message='No visible records. Check the title mapping, selected view and date rules.'; if (empty($records)&&isset($diag['code'])&&200!==$diag['code']) { $message='No records available. Check the connection, base and table, then use Refresh Airtable records.'; } wp_send_json_success(array('html'=>'<p>'.esc_html($message).'</p>','message'=>$message)); }
    wp_send_json_success(array('html'=>$html,'message'=>'Preview ready. Unsaved changes are not published.'));
});
function adb_preview_limit($html,$limit) {
    $count=0;
    return preg_replace_callback('/<(li|article) class="adb-item\b[^>]*>.*?<\/\1>/s',function($match)use(&$count,$limit){ return ++$count<=$limit?$match[0]:''; },$html);
}
