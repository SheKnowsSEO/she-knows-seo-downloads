# Type specific checks

Calculator: define output first, formula, assumptions, units, rate meaning, rounding, valid range, blank and zero behaviour; check 2 independent calculations and negatives. Never present estimates as definitive quotes.
Quiz and assessment: define outcomes and user benefit; map every answer and tie explicitly; define incomplete input behaviour; test every outcome and tie; avoid medical, financial or diagnostic claims.
Generator: define a vetted content bank, selection logic, possibility of repeat outputs, and rights or factual verification. Browser-only generation draws from rules or approved data, not live AI.
Checklist and planner: decide whether progress persists or resets and disclose it; verify optional storage and privacy; test toggles, reset, refresh and mobile.
Spin wheel: keep a clear text result, keyboard-operable button, visual indicator consistent with the result, and motion disabled under reduced-motion preference. Do not imply fairness or prize compliance without independent assessment.
Poll: local response alone does not collect votes or produce aggregate totals. A genuine poll requires a separate authorised backend and a privacy review.
Chart, infographic, timeline: explain units, sources and fictional data; keep a text equivalent; no meaning conveyed by colour alone; test responsive layout and keyboard operation.
All types: use accessible native controls and visible focus, 18px text as baseline, responsive CSS, labelled errors, predictable behaviour, and explicitly test on the actual destination before use. Use reasonable colour contrast and verify with a contrast tool.
