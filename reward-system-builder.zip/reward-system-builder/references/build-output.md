# Blueprint and Build Output

## Concept blueprint

Use this structure after the interview. Keep it practical and proportional.

### The concept

- Working name
- One-sentence experience
- Business goal
- Primary participant
- Success measure
- Evergreen or limited timing

### Enrolment and identity

- Who is eligible
- How they enter the system
- How returning participants are recognised
- Data collected
- Consent, privacy, or security questions

### Action-to-reward map

Use a table with:

| Action | Why it matters | Proof | Frequency/limit | Progress earned | Abuse/error check |
|---|---|---|---|---|---|

### Progress and rewards

- Primary mechanic
- Supporting mechanic, if needed
- Milestones
- Rewards and delivery
- Reset, expiry, refund, reversal, or correction rules
- Approximate fulfilment effort/cost

### Participant experience

- Joining/sign-in
- Home or progress view
- Available actions
- History and proof status
- Next milestone
- Earned rewards
- Help, rules, and accessibility needs

### Owner experience

- Participant management
- Pending approvals
- Event and progress corrections
- Reward fulfilment
- Reporting
- Fraud/duplicate review
- Audit history

### Recommended version 1

- Included now
- Manual steps
- Automated steps
- Tool roles
- Sample data needs
- Testing plan

### Later upgrades

List only upgrades that solve a likely future problem.

### Probably unnecessary

Name tempting complexity that does not help version 1.

### Open decisions and risks

Keep unknowns visible. Flag legal, privacy, security, accessibility, platform, economic, and tracking questions without pretending to provide professional advice.

## Codex build brief

When asked for a build brief, make it usable in a fresh Codex task without prior chat context. Include:

1. **Objective and user:** What to build, for whom, and why.
2. **Version-one scope:** Exact included and excluded features.
3. **User stories:** Participant and admin journeys.
4. **Rules:** Enrolment, actions, verification, progress, rewards, limits, expiry, corrections, and fulfilment.
5. **Data model:** Entities, important fields, relationships, and source-of-truth rules.
6. **Pages and states:** Every participant/admin page plus loading, empty, error, expired, pending, earned, and unauthorised states.
7. **Authentication and permissions:** Proportionate security; never treat an email field as authentication for private data.
8. **Integrations:** Existing tools, desired connections, manual fallback, credentials needed, and approval boundaries.
9. **Design direction:** Brand feel, progress visual, mobile behaviour, accessibility, and copy tone.
10. **Privacy and safety:** Personal data, consent, tracking, secrets, abuse prevention, exports/deletion, and professional review questions.
11. **Sample data:** Use fictional records only during development.
12. **Acceptance checks:** Concrete tests proving calculations, permissions, actions, rewards, corrections, and responsive behaviour work.
13. **Deployment boundary:** Build and verify locally first. Do not publish or connect production data without explicit approval.

End with a short first message the user can paste with the brief, such as:

> Build version 1 from this brief. Start by inspecting the workspace and proposing the smallest safe implementation. Use fictional sample data, keep credentials out of the code, and do not deploy or connect live systems until I approve it.

## Starter build

When explicitly asked and permitted to create files:

- build locally;
- use fictional sample data;
- keep configuration and secrets separate;
- implement the smallest complete participant journey first;
- include clear manual fallbacks;
- test calculations and permission boundaries;
- document unresolved live integrations in the handoff, not as fake working features;
- ask before deployment, paid-service setup, or production-data connection.

