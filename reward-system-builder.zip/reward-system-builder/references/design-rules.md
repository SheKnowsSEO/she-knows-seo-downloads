# Design Rules

Use these rules to turn a vague gamification idea into a credible action-to-reward system.

## The system model

Every concept must define:

1. **Business outcome:** The result the business wants.
2. **Participants:** Who can join and how they become eligible.
3. **Identity:** How the system recognises each person.
4. **Actions:** Behaviours that contribute to the outcome.
5. **Proof:** How each action is verified.
6. **Progress:** How completed actions accumulate or appear.
7. **Rewards:** What becomes available and under what rules.
8. **Participant experience:** What the person can see and do.
9. **Owner experience:** What the business can review, change, and fulfil.
10. **Operations:** Timing, rules, support, privacy, security, and maintenance.

## Action patterns

Use any relevant mix rather than forcing a template:

- **Audience and referrals:** successful referrals, qualified registrations, invited members, shares with evidence.
- **Sales and loyalty:** purchases, repeat purchases, renewal, products collected, spend milestones, retained subscriptions.
- **Engagement:** replies, event attendance, challenges, community contributions, submitted work, resource use.
- **Learning and implementation:** lessons, assignments, quizzes, milestones, practice streaks, selected promotional actions.
- **Content exploration:** clues found, questions answered from a resource, codes collected, trails completed, pages checked off.
- **Limited campaigns:** action checklists, raffle entries, team targets, timed quests, launch or challenge milestones.

Do not reward meaningless activity merely because it is measurable. Avoid incentivising spam, low-quality comments, deceptive referrals, accidental purchases, endless page refreshes, or unsafe disclosure of personal information.

## Proof types

Classify every action:

- **Automatic:** A trusted system records the event.
- **Imported:** The owner periodically imports a verified record.
- **Manual approval:** A person checks and approves evidence.
- **Answer or code:** A correct answer, code, or checkpoint proves completion.
- **Self-reported:** The participant claims completion. Use only when cheating has low consequences.
- **Hybrid:** The system records an event but a person reviews exceptions.

Never describe an action as automatically trackable without identifying the source of truth and how the participant identity matches it.

## Identity and enrolment

Possible enrolment patterns:

- open registration;
- existing subscriber/customer/student/affiliate roster;
- purchase or form-triggered enrolment;
- invitation or unique code;
- temporary campaign registration.

Possible identity patterns:

- existing account login;
- secure email sign-in link;
- user-specific invite or referral code;
- authenticated membership session;
- low-risk email lookup for a non-sensitive prototype.

Do not expose private progress, purchase history, rewards, or personal data through an unverified email lookup. If the concept needs real user accounts, include passwordless authentication or an existing secure account system in the build requirements.

## Progress mechanics

Choose mechanics based on desired behaviour:

- **Points:** Flexible actions with different values.
- **Stamps or check-offs:** Clear repeat actions or a finite set.
- **Badges:** Recognition of specific achievements.
- **Tiers:** Ongoing loyalty or escalating status.
- **Entries:** A limited campaign or prize draw. Flag legal/rules questions.
- **Streaks:** Repetition over time. Include grace/reset rules.
- **Collections:** Exploring categories, completing experiences, or collecting items.
- **Quests:** Sequenced actions with narrative or progressive unlocks.
- **Milestones:** A visible route to guaranteed rewards.
- **Shared goals:** Group progress towards collective unlocks.

Avoid adding multiple currencies or mechanics unless each has a clear purpose.

## Reward design

Consider digital resources, access, recognition, discounts, credit, bonuses, feedback, reviews, physical items, experiences, surprises, or community unlocks.

Check:

- Is the reward wanted by this audience?
- Does it reinforce the business goal?
- Can the business deliver it sustainably?
- Is it guaranteed, limited, random, or conditional?
- Can rewards stack?
- Do points expire or reset?
- What happens after refunds, cancellations, duplicate events, or mistakes?
- Are official rules, eligibility restrictions, disclosures, or professional advice needed?

## Page and content exploration

For bloggers who do not sell yet, meaningful content exploration can drive engagement and pageviews. Prefer:

- a clue trail across related articles;
- a mini quiz whose answers live in the content;
- codes or collection pieces found on selected pages;
- a themed resource passport;
- a finite checklist of useful pages;
- milestone rewards for completing a content path.

Explain that reliable passive pageview attribution may require consent, cookies, logged-in sessions, event tracking, and privacy disclosures. Do not propose inflating pageviews through forced refreshes or low-value clicking.

## Architecture principles

Most systems need these logical records even if version 1 uses a spreadsheet:

- Participants
- Actions
- Action events or submissions
- Progress balance or derived totals
- Milestones
- Rewards
- Reward fulfilments
- Campaigns, when time-limited
- Referrals, when applicable
- Admin adjustments or audit log

Prefer an event ledger as the source of truth. Derive totals from recorded events instead of storing only a balance that can change without explanation.

## Tool selection

Choose tools only after the system is designed. Consider the existing stack, budget, data sensitivity, audience size, integrations, portability, and owner skill level.

When recommending a tool, state:

- what job it would do;
- why it fits this version;
- what could be manual instead;
- any important uncertainty that needs verification.

Read `approved-links.md` for Nina's approved links and affiliate rules. Affiliate availability must never decide the architecture.

